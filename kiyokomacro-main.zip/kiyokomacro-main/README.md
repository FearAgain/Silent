<div id="top"></div>

<h3 align="center">Kiyoko's Mighty Omega Macro</h3>

  <p align="center">
    Macro for the game Mighty Omega using AutoHotkey
    <br />
    <br />
    <a href="https://www.roblox.com/games/4878988249"><strong>Game Link »</strong></a>
    <br />
    <br />
    <a href="https://discord.gg/RCc6ntue5j">My Discord</a>
  </p>
</div>








## About The Macro
Free macro for Mighty Omega. My Discord for more info → [Link](https://discord.gg/RCc6ntue5j)





<!-- GETTING STARTED -->
## Getting Started

- https://www.youtube.com/watch?v=4BbKNg0KraQ
- https://www.youtube.com/watch?v=z9xG2OrK1UM



### Installation

1. Download AutoHotkey → [Link](https://www.autohotkey.com/)
2. Install WinRAR → [Link](https://www.win-rar.com/start.html?&L=0)
3. Download my macro

### Community
   • More info → [Discord](https://discord.gg/RCc6ntue5j)

![Macro](https://cdn.discordapp.com/attachments/805554377745235974/1152657920576720966/GitHub_Banner.png)



